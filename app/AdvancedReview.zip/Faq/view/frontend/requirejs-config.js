var config = {
    map: {
        '*': {
            amfaqSearch: 'Amasty_Faq/js/autosuggest',
            amFaqCollapsible: 'Amasty_Faq/js/faq-collapsible'
        }
    }
};
