<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Advanced Product Reviews Base for Magento 2
 */

namespace Amasty\AdvancedReview\Block\Widget\Wrappers;

class ProductReviewsWrapper extends \Amasty\AdvancedReview\Block\Widget\Wrapper
{

}
