This module allows store-owner to manage the regions & cities from the backend and allows customer to select the city from dropdown.
