<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package B2B Company Account for Magento 2
 */

namespace Amasty\CompanyAccount\Api\Data;

/**
 * @api
 */
interface RoleExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{

}
