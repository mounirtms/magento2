var config = {
    map: {
        "*": {
            "amcorderPopUp": "Amasty_CancelOrder/js/components/popup",
            "amcorderPrompt": "Amasty_CancelOrder/js/components/prompt"
        }
    }
};
