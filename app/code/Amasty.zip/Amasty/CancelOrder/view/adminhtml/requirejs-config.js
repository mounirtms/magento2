var config = {
    map: {
        "*": {
            "amOrderList": "Amasty_CancelOrder/js/components/am-order-list",
            "amOrderConditions": "Amasty_CancelOrder/js/components/am-order-conditions",
        }
    }
};
