var config = {
    map: {
        '*': {
            'spritespin': 'Sm_DegreeView/js/spritespin'
        }
    },
    shim: {
        'spritespin': {
            'deps': ['jquery']
        }
    }
};