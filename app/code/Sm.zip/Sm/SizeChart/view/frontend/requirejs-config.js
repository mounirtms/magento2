var config = {
    deps: [
        'Sm_SizeChart/js/sizechart'
    ]
};