/**
 * SM Social Login - Version 1.0.0
 * Copyright (c) 2017 YouTech Company. All Rights Reserved.
 *
 * @license - Copyrighted Commercial Software
 * Author: YouTech Company
 * Websites: http://www.magentech.com
 */

var config = {
    paths: {
        "Sm_AttributesSearch/js/chosen": 'Sm_AttributesSearch/js/chosen.jquery.min',
        "Sm_AttributesSearch/js/attributes-search": 'Sm_AttributesSearch/js/attributes-search',
    },
    shim: {
        "Sm_AttributesSearch/js/chosen": ["jquery"]
    }
};

