/**
 *  Amasty Cart Compatibility With Recently Viewed Widget
 */

define([
    'jquery'
], function ($) {
    'use strict'; // eslint-disable-line

    var mixin = {
        getDataMageInit: function(row) {
            this._super(row);
            $(document).trigger('amcart_bind');
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
