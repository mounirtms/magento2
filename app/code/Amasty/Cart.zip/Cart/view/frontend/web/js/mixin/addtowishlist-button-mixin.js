/**
 *  Amasty Cart Compatibility With Recently Viewed Widget
 */

define([
    'jquery'
], function ($) {
    'use strict'; // eslint-disable-line

    var mixin = {
        isWishlistAjax: function () {
            return this.source().data['isWishlistAjax'] ?? false;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
