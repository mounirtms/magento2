<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
declare(strict_types=1);

namespace MageWorx\OrdersGrid\Model\ResourceModel\GridAdditionalData\Grid;

use MageWorx\OrdersGrid\Model\ResourceModel\GridAdditionalData\Collection as ParentCollection;

class Collection extends ParentCollection
{

}
