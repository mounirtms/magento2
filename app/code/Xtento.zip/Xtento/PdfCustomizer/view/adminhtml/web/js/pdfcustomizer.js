require([
    "Xtento_PdfCustomizer/js/variables",
    "Xtento_PdfCustomizer/js/editor",
    "Xtento_PdfCustomizer/js/template"
]);