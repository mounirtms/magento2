<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel;

use Magento\Sales\Model\ResourceModel\Order as OriginalOrderResourceModel;

/**
 * Class Order
 */
class Order extends OriginalOrderResourceModel
{

}
