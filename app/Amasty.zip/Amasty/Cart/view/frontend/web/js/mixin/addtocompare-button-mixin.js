/**
 *  Amasty Cart Compatibility With Recently Viewed Widget
 */

define([
    'jquery'
], function ($) {
    'use strict'; // eslint-disable-line

    var mixin = {
        isCompareAjax: function () {
            return this.source().data['isCompareAjax'] ?? false;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
