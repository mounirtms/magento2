var config = {
    config: {
        mixins: {
            'Amasty_Conf/js/swatch-renderer': {
                'Amasty_Cart/js/swatch-renderer': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'Amasty_Cart/js/swatch-renderer': true
            },
            'Magento_Catalog/js/product/addtocart-button': {
                'Amasty_Cart/js/mixin/addtocart-button-mixin': true
            },
            'Magento_Catalog/js/product/addtocompare-button': {
                'Amasty_Cart/js/mixin/addtocompare-button-mixin': true
            },
            'Magento_Wishlist/js/product/addtowishlist-button': {
                'Amasty_Cart/js/mixin/addtowishlist-button-mixin': true
            }
        }
    },
    map: {
        '*': {
            'showConfirmPopup': 'Amasty_Cart/js/show-confirm-popup',
            'Magento_Catalog/template/product/addtocompare-button.html':
                'Amasty_Cart/template/product/addtocompare-button.html',
            'Magento_Wishlist/template/product/addtowishlist-button.html':
                'Amasty_Cart/template/product/addtowishlist-button.html'
        }
    }
};
