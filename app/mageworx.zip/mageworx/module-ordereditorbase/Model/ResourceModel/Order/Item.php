<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel\Order;

use Magento\Sales\Model\ResourceModel\Order\Item as OriginalResourceModel;

/**
 * Class Item
 */
class Item extends OriginalResourceModel
{

}
