<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel;

use Magento\Quote\Model\ResourceModel\Quote as OriginalResourceModel;

/**
 * Class Quote
 */
class Quote extends OriginalResourceModel
{

}
